﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class Level2 : MonoBehaviour
{
    public Text Txt_Score;

    // Start is called before the first frame update
    void Start()
    {
        Coin.Score = 0;
    }

    // Update is called once per frame
    void Update()
    {
        Txt_Score.text = "Score: " + Coin.Score;

        if (Coin.Clear >= 9)
        {
            SceneManager.LoadScene(2);
            Coin.Clear = 0;
        }
    }
}
