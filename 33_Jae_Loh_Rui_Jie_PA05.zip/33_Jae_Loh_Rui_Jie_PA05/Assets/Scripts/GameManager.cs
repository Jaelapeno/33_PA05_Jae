﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public Text Txt_Score;

    // Start is called before the first frame update
    void Start()
    {
        Coin.Score = 0;
    }

    // Update is called once per frame
    void Update()
    {
        Txt_Score.text = "Score: " + Coin.Score;

        if (Coin.Clear >= 5)
        {
            SceneManager.LoadScene(4);
            Coin.Clear = 0;
        }
    }
}
